import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime
import threading


class FileTransferApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Intelligent File Transfer")

        # Create frames for left and right panels
        self.left_frame = tk.Frame(self.root)
        self.left_frame.pack(side="left", padx=10)

        self.right_frame = tk.Frame(self.root)
        self.right_frame.pack(side="right", padx=10)

        # Buttons for directory selection
        self.left_dir_btn = tk.Button(self.left_frame, text="Select Left Directory", command=self.load_left_directory)
        self.left_dir_btn.pack()

        self.right_dir_btn = tk.Button(self.right_frame, text="Select Right Directory",
                                       command=self.load_right_directory)
        self.right_dir_btn.pack()

        # Refresh buttons for directories
        self.refresh_left_btn = tk.Button(self.left_frame, text="Refresh Left Directory", command=self.refresh_left_directory)
        self.refresh_left_btn.pack(pady=5)

        self.refresh_right_btn = tk.Button(self.right_frame, text="Refresh Right Directory", command=self.refresh_right_directory)
        self.refresh_right_btn.pack(pady=5)

        # Listboxes to show files
        self.left_listbox = tk.Listbox(self.left_frame, selectmode=tk.SINGLE, width=40, height=20)
        self.left_listbox.pack()
        self.left_listbox.bind("<<ListboxSelect>>", self.display_metadata)  # Bind event for file click

        self.right_listbox = tk.Listbox(self.right_frame, selectmode=tk.SINGLE, width=40, height=20)
        self.right_listbox.pack()

        # Transfer button
        self.transfer_btn = tk.Button(self.root, text="Transfer File →", command=self.start_transfer_thread)
        self.transfer_btn.pack(pady=10)

        # Label to display file metadata
        self.metadata_label = tk.Label(self.root, text="File metadata will appear here", wraplength=500,
                                       justify=tk.LEFT)
        self.metadata_label.pack(pady=5)

        # Loader label
        self.loader_label = tk.Label(self.root, text="Transferring files, please wait...", bg="yellow", fg="black")
        self.loader_label.pack(pady=5)
        self.loader_label.pack_forget()  # Hide loader initially

        self.left_directory = None
        self.right_directory = None

    def load_left_directory(self):
        self.left_directory = filedialog.askdirectory()
        if self.left_directory:
            self.show_files(self.left_directory, self.left_listbox)

    def load_right_directory(self):
        self.right_directory = filedialog.askdirectory()
        if self.right_directory:
            self.show_files(self.right_directory, self.right_listbox)

    def refresh_left_directory(self):
        if self.left_directory:
            self.show_files(self.left_directory, self.left_listbox)
        else:
            messagebox.showwarning("No Directory Selected", "Please select the left directory first.")

    def refresh_right_directory(self):
        if self.right_directory:
            self.show_files(self.right_directory, self.right_listbox)
        else:
            messagebox.showwarning("No Directory Selected", "Please select the right directory first.")

    def get_folder_size(self, folder_path):
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(folder_path):
            for filename in filenames:
                file_path = os.path.join(dirpath, filename)
                total_size += os.path.getsize(file_path)
        return total_size

    def show_files(self, directory, listbox):
        listbox.delete(0, tk.END)
        try:
            files = os.listdir(directory)
            for file in files:
                listbox.insert(tk.END, file)
        except Exception as e:
            messagebox.showerror("Error", f"Unable to load directory: {e}")

    def display_metadata(self, event):
        # Get selected file/folder
        selected_file_index = event.widget.curselection()
        if selected_file_index:
            selected_file = self.left_listbox.get(selected_file_index)
            selected_file_path = os.path.join(self.left_directory, selected_file)

            if os.path.exists(selected_file_path):
                metadata = self.get_metadata(selected_file_path)
                self.metadata_label.config(text=metadata)

    def get_metadata(self, file_path):
        try:
            metadata = ""
            if os.path.isfile(file_path):
                file_size = os.path.getsize(file_path)
                created_time = datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                modified_time = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                metadata = (f"File: {os.path.basename(file_path)}\n"
                            f"Size: {self.human_readable_size(file_size)}\n"
                            f"Created: {created_time}\n"
                            f"Last Modified: {modified_time}")
            elif os.path.isdir(file_path):
                folder_size = self.get_folder_size(file_path)  # Get folder size
                created_time = datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                modified_time = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                metadata = (f"Directory: {os.path.basename(file_path)}\n"
                            f"Size: {self.human_readable_size(folder_size)}\n"  # Include folder size
                            f"Created: {created_time}\n"
                            f"Last Modified: {modified_time}")
            return metadata
        except Exception as e:
            return f"Error retrieving metadata: {e}"

    def human_readable_size(self, size, decimal_places=2):
        # Convert size in bytes to a human-readable format
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.{decimal_places}f} {unit}"
            size /= 1024.0

    def start_transfer_thread(self):
        # Start the transfer in a new thread
        transfer_thread = threading.Thread(target=self.transfer_file)
        transfer_thread.start()

    def transfer_file(self):
        self.show_loader()  # Show loader
        if not self.left_directory:
            self.hide_loader()  # Hide loader
            self.show_warning("No Directory Selected", "Please select the left directory.")
            return

        if not self.right_directory:
            self.hide_loader()  # Hide loader
            self.show_warning("No Directory Selected", "Please select the right directory.")
            return

        selected_file_index = self.left_listbox.curselection()
        if not selected_file_index:
            self.hide_loader()  # Hide loader
            self.show_warning("No File Selected", "Please select a file or folder from the left directory.")
            return

        selected_file = self.left_listbox.get(selected_file_index)
        source_path = os.path.join(self.left_directory, selected_file)

        # Check if the selected item is a directory
        if os.path.isdir(source_path):
            destination_path = os.path.join(self.right_directory, selected_file)
            if self.check_space(source_path, self.right_directory):  # Check space for directories
                try:
                    shutil.copytree(source_path, destination_path)
                    self.show_info(f"Folder '{selected_file}' transferred successfully!")
                    self.update_file_list(self.right_directory, self.right_listbox)
                except PermissionError:
                    self.show_error(f"You do not have permission to write to '{self.right_directory}'.")
                except Exception as e:
                    self.show_error(f"Error during folder transfer: {e}")
            else:
                self.show_warning("Insufficient Space", "Not enough space in the destination directory.")
        else:  # If it's a file, proceed with the original logic
            destination_path = os.path.join(self.right_directory, selected_file)
            if self.check_space(source_path, self.right_directory):
                try:
                    shutil.copy2(source_path, destination_path)
                    self.show_info(f"File '{selected_file}' transferred successfully!")
                    self.update_file_list(self.right_directory, self.right_listbox)
                except PermissionError:
                    self.show_error(f"You do not have permission to write to '{self.right_directory}'.")
                except Exception as e:
                    self.show_error(f"Error during file transfer: {e}")
            else:
                self.show_warning("Insufficient Space", "Not enough space in the destination directory.")

        self.hide_loader()  # Hide loader after transfer completes

    def check_space(self, source_path, destination_directory):
        # Check if there is enough space in the destination directory for the source
        source_size = self.get_folder_size(source_path) if os.path.isdir(source_path) else os.path.getsize(source_path)
        total, used, free = shutil.disk_usage(destination_directory)
        return free >= source_size

    def show_loader(self):
        self.loader_label.pack()  # Show loader
        self.loader_label.update_idletasks()  # Update the UI

    def hide_loader(self):
        self.loader_label.pack_forget()  # Hide loader

    def show_info(self, message):
        messagebox.showinfo("Information", message)

    def show_warning(self, title, message):
        messagebox.showwarning(title, message)

    def show_error(self, message):
        messagebox.showerror("Error", message)

    def update_file_list(self, directory, listbox):
        self.show_files(directory, listbox)


if __name__ == "__main__":
    root = tk.Tk()
    app = FileTransferApp(root)
    root.mainloop()
